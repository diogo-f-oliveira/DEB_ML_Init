function [data, auxData, metaData, txtData, weights] = mydata_Perna_canaliculus

%% set metadata

metaData.phylum     = 'Mollusca'; 
metaData.class      = 'Bivalvia'; 
metaData.order      = 'Mytiloida'; 
metaData.family     = 'Mytilidae ';
metaData.species    = 'Perna canaliculus '; 
metaData.species_en = 'Greenshell mussel'; 
metaData.T_typical  = C2K(15); % K, body temp
metaData.data_0     = {'ab'; 'ap'; 'am'; 'Lb'; 'Lp'; 'Li'; 'Wdb'; 'Wdp'; 'Wdi'; 'GSI'; 'Ri'};
metaData.data_1     = {'t-L_f', 't-Wd_f'};

metaData.COMPLETE = 2.5; % using criteria of LikaKear2011

metaData.author   = {'Jeffrey Ren'};                            
metaData.date_subm = [2018 12 11];                            
metaData.email    = {'jeffrey.ren@niwa.co.nz', 'jeffrey.ren2012@gmail.com'};                  
metaData.address  = {'National Institute of Water and Atmospheric Research, PO Box 8602, Christchurch 8440, New Zealand'}; 

metaData.curator     = {'Bas Kooijman'};
metaData.email_cur   = {'bas.kooijman@vu.nl'}; 
metaData.date_acc    = [2018 12 11]; 



%% set data
% zero-variate data;

data.ab = 5;      units.ab = 'd';    label.ab = 'age at birth';             bibkey.ab = 'Buchann1998';   
  temp.ab = C2K(12);  units.temp.ab = 'K'; label.temp.ab = 'temperature';
data.tp = 270;    units.tp = 'd';    label.tp = 'time since birth at puberty'; bibkey.tp = 'Alfaro2001';
  temp.tp = C2K(17);  units.temp.tp = 'K'; label.temp.tp = 'temperature';
data.am = 20 * 365; units.am = 'd';    label.am = 'life span';                bibkey.am = 'guessed';
  temp.am = C2K(15);  units.temp.am = 'K'; label.temp.am = 'temperature'; 

data.Lb  = 0.05; units.Lb  = 'cm';  label.Lb  = 'shell length at birth';   bibkey.Lb  = 'Alfaro2001';
data.Lp  = 2.7;  units.Lp  = 'cm';  label.Lp  = 'shell length at puberty'; bibkey.Lp  = 'Alfaro2001';
data.Li  = 24;  units.Li  = 'cm';  label.Li  = 'ultimate total length';    bibkey.Li = 'Wiki';

data.Wdb = 1e-6;   units.Wdb = 'g';   label.Wdb = 'dry weight at birth';    bibkey.Wdb = 'guessed';
data.Wdp = 0.5;   units.Wdp = 'g';   label.Wdp = 'dry weight at puberty';    bibkey.Wdp = 'calculated';
  comment.Wdp = 'calculation based on length-weight relationship from NIWA unpublished data';
data.Wdi = 35;   units.Wdi = 'g';   label.Wdi = 'ultimate dry weight';    bibkey.Wdi = 'guessed';

data.GSI  = 0.14; units.GSI  = '-'; label.GSI  = 'gonado somatic index';    bibkey.GSI  = 'NIWA unpublished data';   
  temp.GSI = C2K(16); units.temp.GSI = 'K'; label.temp.GSI = 'temperature';
  comment.GSI = 'GSI is both temporally and spatially variable';
   
data.Ri  = 1e7/365; units.Ri  = '#/d';  label.Ri  = 'maximum reprod rate';     bibkey.Ri  = 'Buchann1998';   
temp.Ri = C2K(18);  units.temp.Ri = 'K'; label.temp.Ri = 'temperature';
  comment.Ri = 'Esimated value';
    
% uni-variate data
% t-L data (site 1)
data.tL1 = [ ... % time (yr), length (cm)
1.030	1.274	1.312	1.359	1.447	1.526	1.611	1.693	1.778	1.860	1.945	2.030
4.79	5.99	6.3	6.72	6.72	7.23	7.51	7.95	7.96	8.68	9.30	9.37]';
data.tL1(:,1) = data.tL1(:,1) * 365; % conver age in year to day
units.tL1 = {'d', 'cm'};     label.tL1 = {'time since birth', 'length'}; 
  temp.tL1 = C2K(15);  units.temp.tL1 = 'K'; label.temp.tL1 = 'temperature';
  bibkey.tL1 = 'NIWA unpublished data'; comment.tL1 = 'annual mean temperature';

% t-W data (site 1)
data.tW1 = [ ... % time (d), dry weight (g)
1.030	1.274	1.312	1.359	1.447	1.526	1.611	1.693	1.778	1.860	1.945	2.030
0.35	0.71	0.8	0.91	1.11	1.27	1.57	1.86	2.02	2.31	2.80	2.38]';
data.tW1(:,1) = data.tW1(:,1) * 365; % conver age in year to day
units.tW1   = {'d', 'g'};  label.tW1 = {'time', 'dry weight'};  
 temp.tW1    = C2K(15);  units.temp.tW1 = 'K'; label.temp.tW1 = 'temperature';
 bibkey.tW1 = 'NIWA unpublished data';

% t-L data (site 2)
data.tL2 = [ ... % time (yr), length (cm)
1.030	1.274	1.312	1.359	1.447	1.526	1.611	1.693	1.778	1.860	1.945	2.030
4.79	6.46	6.53	6.85	7.35	7.32	7.79	8.18	8.47	9.28	9.56	9.54]';
data.tL2(:,1) = data.tL2(:,1) * 365; % conver age in year to day
units.tL2 = {'d', 'cm'};     label.tL2 = {'time since birth', 'length'}; 
  temp.tL2 = C2K(15);  units.temp.tL2 = 'K'; label.temp.tL2 = 'temperature';
  bibkey.tL2 = 'NIWA unpublished data'; comment.tL2 = 'annual mean temperature'; %#ok<STRNU>

% t-W data (site 2)
data.tW2 = [ ... % time (d), dry weight (g)
1.030	1.274	1.312	1.359	1.447	1.526	1.611	1.693	1.778	1.860	1.945	2.030
0.35	0.87	0.9	0.96	1.05	1.07	1.7	2.18	2.41	3.22	3.13	3.08]';
data.tW2(:,1) = data.tW2(:,1) * 365; % conver age in year to day
units.tW2   = {'d', 'g'};  label.tW2 = {'time', 'dry weight'};  
temp.tW2    = C2K(15);  units.temp.tW2 = 'K'; label.temp.tW2 = 'temperature';
bibkey.tW2 = 'NIWA unpublished data';

%% set weights for all real data
weights = setweights(data, []);
weights.tL1 = 5 * weights.tL1;
weights.tL2 = 5 * weights.tL2;

%% set pseudodata and respective weights
[data, units, label, weights] = addpseudodata(data, units, label, weights);

%% pack auxData and txtData for output
auxData.temp = temp;
txtData.units = units;
txtData.label = label;
txtData.bibkey = bibkey;

%% Group plots
set1 = {'tL2','tL1'}; comment1 = {'Growth at two culture sites'};
set2 = {'tW2','tW1'}; comment2 = {'Growth at two culture sites'};
metaData.grp.sets = {set1,set2};
metaData.grp.comment = {comment1,comment2};

%% References
bibkey = 'Wiki'; type = 'Misc'; bib = ...
'howpublished = {\url{https://en.wikipedia.org/wiki/Perna_canaliculus}}';
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Kooy2010'; type = 'Book'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Kooijman, S.A.L.M.}, ' ...
'year = {2010}, ' ...
'title  = {Dynamic Energy Budget theory for metabolic organisation}, ' ...
'publisher = {Cambridge Univ. Press, Cambridge}, ' ...
'pages = {Table 4.2 (page 150), 8.1 (page 300)}, ' ...
'howpublished = {\url{http://www.bio.vu.nl/thb/research/bib/Kooy2010.html}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Alfaro2001'; type = 'phdthesis'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Alfaro, A.C.}, ' ...
'year = {2001}, ' ...
'title  = {Ecological dynamics of the greenshell-lipped mussel, \emph{Perna canaliculus}, at {N}inety {M}ile {B}each, {N}orthern {N}ew {Z}ealand}, ' ...
'school = {University of Auckland}, ' ...
'pages = {238p}, ' ...
'howpublished = {\url{https://www.auckland.ac.nz}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];
%
bibkey = 'Buchann1998'; type = 'phdthesis'; bib = [ ...  % used in setting of chemical parameters and pseudodata
'author = {Buchann S.}, ' ...
'year = {1998}, ' ...
'title  = {Spat production of the Greenshell mussel, \emph{Perna canaciliculus} in {N}ew {Z}ealand}, ' ...
'shool = {Auckland University}, ' ...
'pages = {232p}, ' ...
'howpublished = {\url{https://www.auckland.ac.nz}}'];
metaData.biblist.(bibkey) = ['''@', type, '{', bibkey, ', ' bib, '}'';'];

